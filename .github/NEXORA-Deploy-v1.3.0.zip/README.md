# NEXORA Android App

NEXORA is an Android stopwatch, countdown timer, alarm, and history app built with Kotlin and Jetpack Compose.

## v1.2.0 changes
- Fixed the main layout so the four-tab bottom navigation remains visible.
- Removed the non-functional speaker and settings buttons from the top bar.
- Replaced launcher icon artwork with a stopwatch-and-cat themed NEXORA icon.
- Bumped Android version to 1.2.0 (versionCode 2).

## Build
Use Android Studio or run `gradle :app:assembleDebug` with JDK 17 and Android SDK 35 installed.

The GitHub Actions workflow in `.github/workflows/android.yml` builds a debug APK and uploads it as an artifact.

## Release signing

Release builds use a persistent private signing key supplied through GitHub Actions Secrets. Never commit the keystore or its passwords to this repository.
