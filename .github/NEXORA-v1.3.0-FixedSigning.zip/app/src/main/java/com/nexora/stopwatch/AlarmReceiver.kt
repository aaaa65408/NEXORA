package com.nexora.stopwatch

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("alarm_id", 0)
        val label = intent.getStringExtra("alarm_label") ?: "NEXORA 鬧鐘"
        AlarmAlertService.start(context, id, label)

        // Keep enabled alarms recurring daily after they ring.
        val prefs = context.getSharedPreferences("nexora", Context.MODE_PRIVATE)
        try {
            val arr = org.json.JSONArray(prefs.getString("alarms", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                if (item.optInt("id") == id && item.optBoolean("enabled", false)) {
                    val cal = java.util.Calendar.getInstance().apply {
                        set(java.util.Calendar.HOUR_OF_DAY, item.getInt("hour"))
                        set(java.util.Calendar.MINUTE, item.getInt("minute"))
                        set(java.util.Calendar.SECOND, 0)
                        set(java.util.Calendar.MILLISECOND, 0)
                        add(java.util.Calendar.DAY_OF_YEAR, 1)
                    }
                    schedule(context, id, cal.timeInMillis, item.optString("label", label))
                    break
                }
            }
        } catch (_: Exception) { }
    }

    companion object {
        fun schedule(context: Context, id: Int, triggerAtMillis: Long, label: String) {
            val intent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra("alarm_id", id); putExtra("alarm_label", label)
            }
            val pi = PendingIntent.getBroadcast(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val showIntent = PendingIntent.getActivity(
                context, 9000 + id,
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent), pi)
        }

        fun cancel(context: Context, id: Int) {
            val intent = Intent(context, AlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
        }
    }
}

class CountdownReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        CountdownAlertService.start(context)
        saveHistory(context, "倒數計時", "背景完成")
        context.getSharedPreferences("nexora", Context.MODE_PRIVATE).edit()
            .putBoolean("countdown_running", false).putLong("countdown_end_epoch", 0L).apply()
    }

    companion object {
        fun schedule(context: Context, targetEpochMillis: Long) {
            val intent = Intent(context, CountdownReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context, 2001, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 23) {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, targetEpochMillis, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, targetEpochMillis, pi)
                }
            } else am.setExact(AlarmManager.RTC_WAKEUP, targetEpochMillis, pi)
        }

        fun cancel(context: Context) {
            val pi = PendingIntent.getBroadcast(
                context, 2001, Intent(context, CountdownReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("nexora", Context.MODE_PRIVATE)
        val raw = prefs.getString("alarms", "[]") ?: "[]"
        try {
            val arr = org.json.JSONArray(raw)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                if (!item.optBoolean("enabled", false)) continue
                val id = item.getInt("id")
                val hour = item.getInt("hour")
                val minute = item.getInt("minute")
                val label = item.optString("label", "提醒")
                val cal = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, hour)
                    set(java.util.Calendar.MINUTE, minute)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
                }
                AlarmReceiver.schedule(context, id, cal.timeInMillis, label)
            }
        } catch (_: Exception) { }

        val countdownEnd = prefs.getLong("countdown_end_epoch", 0L)
        if (prefs.getBoolean("countdown_running", false) && countdownEnd > System.currentTimeMillis()) {
            CountdownReceiver.schedule(context, countdownEnd)
        } else if (prefs.getBoolean("countdown_running", false)) {
            prefs.edit().putBoolean("countdown_running", false).putLong("countdown_end_epoch", 0L).apply()
        }
    }
}


class AlarmAlertService : android.app.Service() {
    private var player: android.media.MediaPlayer? = null
    private var vibrator: android.os.Vibrator? = null

    override fun onBind(intent: Intent?): android.os.IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val label = intent?.getStringExtra("alarm_label") ?: "提醒"
        val channelId = "nexora_alarm_alert"
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                android.app.NotificationChannel(channelId, "鬧鐘響鈴", android.app.NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val stopIntent = Intent(this, AlarmAlertService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 4100, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = androidx.core.app.NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("NEXORA 鬧鐘")
            .setContentText("$label — 音效與震動提醒中")
            .setOngoing(true)
            .setCategory(androidx.core.app.NotificationCompat.CATEGORY_ALARM)
            .addAction(android.R.drawable.ic_media_pause, "停止鬧鐘", stopPending)
            .build()
        startForeground(4100, notification)

        if (player == null) {
            player = android.media.MediaPlayer.create(this, R.raw.alarm_clock)?.apply {
                isLooping = true
                setVolume(1f, 1f)
                start()
            }
        }
        if (vibrator == null) {
            vibrator = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(android.os.VibratorManager::class.java).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            }
        }
        val pattern = longArrayOf(0, 500, 250, 500, 700)
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator?.vibrate(android.os.VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { player?.stop() } catch (_: Exception) { }
        player?.release()
        player = null
        vibrator?.cancel()
        vibrator = null
        (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(4100)
        super.onDestroy()
    }

    companion object {
        private const val ACTION_STOP = "com.nexora.stopwatch.STOP_ALARM_ALERT"
        fun start(context: Context, id: Int, label: String) {
            val intent = Intent(context, AlarmAlertService::class.java).apply {
                putExtra("alarm_id", id)
                putExtra("alarm_label", label)
            }
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}


class CountdownAlertService : android.app.Service() {
    private var player: android.media.MediaPlayer? = null
    private var vibrator: android.os.Vibrator? = null

    override fun onBind(intent: Intent?): android.os.IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val channelId = "nexora_countdown_alert"
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                android.app.NotificationChannel(channelId, "計時器響鈴", android.app.NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val stopIntent = Intent(this, CountdownAlertService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 4200, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("NEXORA 計時器")
            .setContentText("倒數結束 — 音效與震動提醒中")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .addAction(android.R.drawable.ic_media_pause, "停止提醒", stopPending)
            .build()
        startForeground(4200, notification)

        if (player == null) {
            player = android.media.MediaPlayer.create(this, R.raw.timer_beeps)?.apply {
                isLooping = true
                setVolume(1f, 1f)
                start()
            }
        }
        if (vibrator == null) {
            vibrator = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(android.os.VibratorManager::class.java).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            }
        }
        val pattern = longArrayOf(0, 350, 180, 350, 650)
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator?.vibrate(android.os.VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { player?.stop() } catch (_: Exception) { }
        player?.release()
        player = null
        vibrator?.cancel()
        vibrator = null
        (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(4200)
        super.onDestroy()
    }

    companion object {
        private const val ACTION_STOP = "com.nexora.stopwatch.STOP_COUNTDOWN_ALERT"
        fun start(context: Context) {
            val intent = Intent(context, CountdownAlertService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
        fun stop(context: Context) {
            val intent = Intent(context, CountdownAlertService::class.java).setAction(ACTION_STOP)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}
