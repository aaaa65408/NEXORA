package com.nexora.stopwatch

import android.app.Activity
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest
import com.google.android.libraries.ads.mobile.sdk.common.PreloadConfiguration
import com.google.android.libraries.ads.mobile.sdk.appopen.AppOpenAdEventCallback
import com.google.android.libraries.ads.mobile.sdk.appopen.AppOpenAdPreloader
import com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError

/**
 * NEXORA uses Google's official test ad units while the app is being developed.
 * Replace TEST_*_AD_UNIT_ID with the production unit IDs only for a release build
 * after the integration has been verified and the app is ready to publish.
 */
internal object NexoraAdConfig {
    const val ADMOB_APP_ID = "ca-app-pub-4414573802111123~9564981825"
    const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/9214589741"
    const val TEST_APP_OPEN_AD_UNIT_ID = "ca-app-pub-3940256099942544/9257395921"
    val BANNER_AD_UNIT_ID: String
        get() = if (BuildConfig.DEBUG) TEST_BANNER_AD_UNIT_ID else PRODUCTION_BANNER_AD_UNIT_ID
    val APP_OPEN_AD_UNIT_ID: String
        get() = if (BuildConfig.DEBUG) TEST_APP_OPEN_AD_UNIT_ID else PRODUCTION_APP_OPEN_AD_UNIT_ID

    // Production IDs supplied from the user's AdMob account.
    const val PRODUCTION_BANNER_AD_UNIT_ID = "ca-app-pub-4414573802111123/1630651481"
    const val PRODUCTION_APP_OPEN_AD_UNIT_ID = "ca-app-pub-4414573802111123/3508381920"
}

internal object NexoraAppOpenAds {
    @Volatile var sdkReady: Boolean = false
        private set

    @Volatile private var preloaderStarted = false
    @Volatile private var isShowing = false

    fun markSdkReady() {
        if (preloaderStarted) {
            sdkReady = true
            return
        }
        val request = AdRequest.Builder(NexoraAdConfig.APP_OPEN_AD_UNIT_ID).build()
        val config = PreloadConfiguration(request)
        AppOpenAdPreloader.start(NexoraAdConfig.APP_OPEN_AD_UNIT_ID, config)
        preloaderStarted = true
        sdkReady = true
    }

    fun tryShow(activity: Activity, hasShownThisForeground: Boolean, onShowingChanged: (Boolean) -> Unit): Boolean {
        if (!sdkReady || isShowing || hasShownThisForeground || activity.isFinishing || activity.isDestroyed) {
            return false
        }
        if (!AppOpenAdPreloader.isAdAvailable(NexoraAdConfig.APP_OPEN_AD_UNIT_ID)) {
            return false
        }
        val ad = AppOpenAdPreloader.pollAd(NexoraAdConfig.APP_OPEN_AD_UNIT_ID) ?: return false
        isShowing = true
        onShowingChanged(true)
        ad.adEventCallback = object : AppOpenAdEventCallback {
            override fun onAdDismissedFullScreenContent() {
                isShowing = false
                ad.destroy()
                onShowingChanged(false)
            }

            override fun onAdFailedToShowFullScreenContent(fullScreenContentError: FullScreenContentError) {
                isShowing = false
                ad.destroy()
                onShowingChanged(false)
            }
        }
        ad.show(activity)
        return true
    }

    fun isShowing(): Boolean = isShowing
}
