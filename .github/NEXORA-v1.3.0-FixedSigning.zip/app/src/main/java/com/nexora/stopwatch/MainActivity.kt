package com.nexora.stopwatch

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF080F22)
private val Panel = Color(0xFF111D38)
private val Cyan = Color(0xFF56D9FF)
private val Violet = Color(0xFF9A7BFF)
private val Muted = Color(0xFF9BAAC8)

data class AlarmItem(val id: Int, val hour: Int, val minute: Int, val label: String, val enabled: Boolean)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { NexoraApp() }
    }
}

@Composable
fun NexoraApp() {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(2) }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Violet, background = Navy, surface = Panel,
        onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF080F22), Color(0xFF0B1530), Color(0xFF070D1D))))) {
                // The content must take only the remaining height; otherwise fillMaxSize()
                // inside each screen can push the bottom navigation completely off-screen.
                Box(Modifier.weight(1f).fillMaxWidth().padding(top = 12.dp)) {
                    when (tab) {
                        0 -> AlarmScreen(context)
                        1 -> CountdownScreen(context)
                        2 -> StopwatchScreen(context)
                        else -> HistoryScreen(context)
                    }
                }
                NavigationBar(containerColor = Color(0xFF101B35), contentColor = Muted, tonalElevation = 0.dp) {
                    val items = listOf("鬧鐘", "計時器", "碼表", "紀錄")
                    val icons = listOf(Icons.Default.Alarm, Icons.Default.HourglassTop, Icons.Default.Timer, Icons.Default.History)
                    items.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = label, modifier = Modifier.size(25.dp)) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White, selectedTextColor = Color.White,
                                indicatorColor = Color(0xFF174A8A), unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppTopBar(title: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = { onBack.invoke() }) {
                Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.size(27.dp))
            }
        } else {
            Spacer(Modifier.width(48.dp))
        }
        Spacer(Modifier.weight(1f))
        Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.weight(1f))
        // No decorative speaker/settings controls until they have real implemented actions.
        Spacer(Modifier.width(48.dp))
    }
}

@Composable
fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(20.dp), content = content)
    }
}

fun timeText(ms: Long): String {
    val total = ms.coerceAtLeast(0)
    val h = total / 3_600_000
    val m = (total / 60_000) % 60
    val s = (total / 1_000) % 60
    val cs = (total % 1_000) / 10
    return "%02d:%02d:%02d.%02d".format(h, m, s, cs)
}

@Composable
fun StopwatchScreen(context: Context) {
    var running by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var startedAt by remember { mutableLongStateOf(0L) }
    var laps by remember { mutableStateOf(listOf<Long>()) }
    LaunchedEffect(running) {
        while (running) {
            elapsed = SystemClock.elapsedRealtime() - startedAt
            kotlinx.coroutines.delay(10)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(16.dp))
        AppTopBar("碼表")
        Image(
            painter = painterResource(id = R.drawable.cat_neon_header),
            contentDescription = "NEXORA 灰白長毛貓",
            modifier = Modifier.fillMaxWidth().height(150.dp).padding(horizontal = 8.dp),
            contentScale = ContentScale.Fit
        )
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp).border(
                width = 2.dp,
                brush = Brush.linearGradient(listOf(Cyan, Color(0xFF5E8BFF), Violet, Cyan)),
                shape = RoundedCornerShape(42.dp)
            ).background(Color(0xFF09152D), RoundedCornerShape(42.dp)).padding(horizontal = 12.dp, vertical = 22.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(timeText(elapsed), fontSize = 43.sp, fontWeight = FontWeight.Light, color = Color(0xFFF3F7FF), letterSpacing = (-1).sp, maxLines = 1)
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("時", "分", "秒", "毫秒").forEach { Text(it, color = Muted, fontSize = 12.sp) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 18.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            RoundActionButton(Icons.Default.Refresh, "重設", false, onClick = {
                if (running) { running = false; saveHistory(context, "秒錶", timeText(elapsed)) }
                elapsed = 0L; laps = emptyList()
            })
            RoundActionButton(if (running) Icons.Default.Pause else Icons.Default.PlayArrow, if (running) "暫停" else "開始", true, onClick = {
                if (running) { elapsed = SystemClock.elapsedRealtime() - startedAt; running = false }
                else { startedAt = SystemClock.elapsedRealtime() - elapsed; running = true }
            })
            RoundActionButton(Icons.Default.Flag, "計次", false, enabled = running, onClick = { laps = listOf(elapsed) + laps })
        }
        Card(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).border(1.dp, Color(0xFF34466F), RoundedCornerShape(24.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111D38)), shape = RoundedCornerShape(24.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FormatListBulleted, null, tint = Color.White)
                        Spacer(Modifier.width(12.dp))
                        Text("計次紀錄 (${laps.size})", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Text("${laps.size} LAP", color = Cyan, fontSize = 11.sp)
                }
                HorizontalDivider(Modifier.padding(top = 12.dp), color = Color(0xFF293B60))
                if (laps.isEmpty()) {
                    Column(Modifier.fillMaxWidth().height(145.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Timer, null, tint = Color(0xFF8196C5), modifier = Modifier.size(42.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("尚無計次紀錄", color = Color(0xFFB4C3E2), fontSize = 15.sp)
                        Text("開始後可點「計次」記錄每一圈時間", color = Muted, fontSize = 12.sp)
                    }
                } else {
                    laps.forEachIndexed { i, lap ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("第 ${laps.size - i} 圈", color = Color(0xFFD9E5FF))
                            Text(timeText(lap), color = Cyan, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun RoundActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, primary: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val fill = if (primary) Brush.linearGradient(listOf(Color(0xFF00BFFF), Color(0xFF0756C8), Color(0xFF102F79))) else Brush.linearGradient(listOf(Color(0xFF273653), Color(0xFF121D35)))
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(100.dp)) {
        Box(
            Modifier.size(if (primary) 108.dp else 88.dp)
                .border(if (primary) 2.dp else 1.dp, if (enabled) Brush.linearGradient(listOf(Cyan, Violet)) else Brush.linearGradient(listOf(Color(0xFF34415D), Color(0xFF34415D))), CircleShape)
                .background(fill, CircleShape)
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = if (enabled) Color.White else Muted, modifier = Modifier.size(if (primary) 42.dp else 34.dp))
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = if (enabled) Color.White else Muted, fontSize = 15.sp)
    }
}

@Composable
fun CountdownScreen(context: Context) {
    var hours by remember { mutableIntStateOf(0) }
    var minutes by remember { mutableIntStateOf(5) }
    var seconds by remember { mutableIntStateOf(0) }
    var remaining by remember { mutableLongStateOf(0L) }
    var endAt by remember { mutableLongStateOf(0L) }
    var running by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("nexora", Context.MODE_PRIVATE)
        val savedEnd = prefs.getLong("countdown_end_epoch", 0L)
        val wasRunning = prefs.getBoolean("countdown_running", false)
        if (wasRunning && savedEnd > System.currentTimeMillis()) {
            endAt = SystemClock.elapsedRealtime() + (savedEnd - System.currentTimeMillis())
            remaining = savedEnd - System.currentTimeMillis()
            running = true
        } else if (wasRunning) {
            prefs.edit().putBoolean("countdown_running", false).putLong("countdown_end_epoch", 0L).apply()
            remaining = 0L
            finished = true
        }
    }

    LaunchedEffect(running) {
        while (running) {
            remaining = (endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            if (remaining == 0L) {
                running = false
                finished = true
                CountdownReceiver.cancel(context)
                context.getSharedPreferences("nexora", Context.MODE_PRIVATE).edit()
                    .putBoolean("countdown_running", false).putLong("countdown_end_epoch", 0L).apply()
                saveHistory(context, "倒數計時", "完成")
            } else kotlinx.coroutines.delay(100)
        }
    }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(44.dp))
        Text("COUNTDOWN", color = Muted, letterSpacing = 3.sp, fontSize = 11.sp)
        Text(timeText(remaining), fontSize = 36.sp, color = Color.White, fontWeight = FontWeight.Light)
        if (!running && remaining == 0L) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                NumberPicker("時", hours, 23) { hours = it }
                NumberPicker("分", minutes, 59) { minutes = it }
                NumberPicker("秒", seconds, 59) { seconds = it }
            }
        }
        if (finished) Text("時間到！通知已送出", color = Cyan, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 24.dp)) {
            OutlinedButton(onClick = {
                running = false
                CountdownReceiver.cancel(context)
                remaining = 0L
                finished = false
                context.getSharedPreferences("nexora", Context.MODE_PRIVATE).edit()
                    .putBoolean("countdown_running", false).putLong("countdown_end_epoch", 0L).apply()
            }) { Text("重設") }
            Button(onClick = {
                if (running) {
                    remaining = (endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
                    running = false
                    CountdownReceiver.cancel(context)
                    context.getSharedPreferences("nexora", Context.MODE_PRIVATE).edit()
                        .putBoolean("countdown_running", false).putLong("countdown_end_epoch", 0L).apply()
                } else {
                    val duration = if (remaining > 0) remaining else (hours * 3600L + minutes * 60L + seconds) * 1000L
                    if (duration > 0) {
                        remaining = duration
                        endAt = SystemClock.elapsedRealtime() + duration
                        running = true
                        finished = false
                        val targetEpoch = System.currentTimeMillis() + duration
                        context.getSharedPreferences("nexora", Context.MODE_PRIVATE).edit()
                            .putBoolean("countdown_running", true).putLong("countdown_end_epoch", targetEpoch).apply()
                        CountdownReceiver.schedule(context, targetEpoch)
                    }
                }
            }, colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
                Text(if (running) "暫停" else if (remaining > 0) "繼續" else "開始", color = Navy)
            }
        }
        Text("背景倒數到期會發送通知；暫停後可繼續", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 18.dp))
    }
}

@Composable
fun NumberPicker(label: String, value: Int, max: Int, onChange: (Int) -> Unit) {
    Column(
        Modifier.weight(1f),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Muted, textAlign = TextAlign.Center)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            IconButton(
                onClick = { onChange((value - 1).coerceAtLeast(0)) },
                modifier = Modifier.size(36.dp)
            ) { Icon(Icons.Default.Remove, null, tint = Cyan) }
            Text(
                "%02d".format(value),
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(30.dp)
            )
            IconButton(
                onClick = { onChange((value + 1).coerceAtMost(max)) },
                modifier = Modifier.size(36.dp)
            ) { Icon(Icons.Default.Add, null, tint = Cyan) }
        }
    }
}

@Composable
fun AlarmScreen(context: Context) {
    var alarms by remember { mutableStateOf(loadAlarms(context)) }
    var label by remember { mutableStateOf("提醒") }
    fun persist(list: List<AlarmItem>) { alarms = list; storeAlarms(context, list) }
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(16.dp))
        if (Build.VERSION.SDK_INT >= 31) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            if (!alarmManager.canScheduleExactAlarms()) {
                PanelCard {
                    Text("需要鬧鐘權限", fontWeight = FontWeight.Bold)
                    Text("若要讓鬧鐘盡量準時響起，請允許 NEXORA 設定精確鬧鐘。", color = Muted, fontSize = 12.sp)
                    Button(
                        onClick = {
                            val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                data = android.net.Uri.parse("package:${context.packageName}")
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier.padding(top = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan)
                    ) { Text("前往開啟精確鬧鐘權限", color = Navy) }
                }
            }
        }
        PanelCard {
            Text("新增鬧鐘", fontWeight = FontWeight.Bold)
            OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("提醒名稱") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                val now = java.util.Calendar.getInstance()
                TimePickerDialog(context, { _, h, m ->
                    val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
                    val item = AlarmItem(id, h, m, label.ifBlank { "提醒" }, true)
                    persist(alarms + item)
                    scheduleAlarm(context, item)
                }, now.get(java.util.Calendar.HOUR_OF_DAY), now.get(java.util.Calendar.MINUTE), true).show()
            }, modifier = Modifier.padding(top = 12.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
                Text("選擇時間並新增", color = Navy)
            }
        }
        LazyColumn {
            items(alarms, key = { it.id }) { alarm ->
                PanelCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("%02d:%02d".format(alarm.hour, alarm.minute), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Text(alarm.label, color = Muted)
                        }
                        IconButton(onClick = {
                            TimePickerDialog(context, { _, h, m ->
                                val updated = alarm.copy(hour = h, minute = m)
                                persist(alarms.map { if (it.id == alarm.id) updated else it })
                                AlarmReceiver.cancel(context, alarm.id)
                                if (updated.enabled) scheduleAlarm(context, updated)
                            }, alarm.hour, alarm.minute, true).show()
                        }) { Icon(Icons.Default.Edit, "編輯時間", tint = Cyan) }
                        Switch(checked = alarm.enabled, onCheckedChange = { enabled ->
                            val updated = alarm.copy(enabled = enabled)
                            persist(alarms.map { if (it.id == alarm.id) updated else it })
                            if (enabled) scheduleAlarm(context, updated) else AlarmReceiver.cancel(context, alarm.id)
                        })
                        IconButton(onClick = {
                            AlarmReceiver.cancel(context, alarm.id)
                            persist(alarms.filterNot { it.id == alarm.id })
                        }) { Icon(Icons.Default.Delete, "刪除", tint = Color(0xFFFF7B91)) }
                    }
                }
            }
        }
        if (alarms.isEmpty()) Text("尚未建立鬧鐘", color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally).padding(20.dp))
    }
}

fun scheduleAlarm(context: Context, item: AlarmItem) {
    if (!item.enabled) return
    val cal = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, item.hour); set(java.util.Calendar.MINUTE, item.minute)
        set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
    }
    AlarmReceiver.schedule(context, item.id, cal.timeInMillis, item.label)
}

fun loadAlarms(context: Context): List<AlarmItem> {
    val raw = context.getSharedPreferences("nexora", Context.MODE_PRIVATE).getString("alarms", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            AlarmItem(o.getInt("id"), o.getInt("hour"), o.getInt("minute"), o.getString("label"), o.getBoolean("enabled"))
        }
    } catch (_: Exception) { emptyList() }
}
fun storeAlarms(context: Context, alarms: List<AlarmItem>) {
    val arr = JSONArray()
    alarms.forEach { arr.put(JSONObject().put("id", it.id).put("hour", it.hour).put("minute", it.minute).put("label", it.label).put("enabled", it.enabled)) }
    context.getSharedPreferences("nexora", Context.MODE_PRIVATE).edit().putString("alarms", arr.toString()).apply()
}

@Composable
fun HistoryScreen(context: Context) {
    var records by remember { mutableStateOf(loadHistory(context)) }
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(16.dp))
        PanelCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("歷史紀錄", fontWeight = FontWeight.Bold)
                TextButton(onClick = { context.getSharedPreferences("nexora", Context.MODE_PRIVATE).edit().remove("history").apply(); records = emptyList() }) { Text("清除全部", color = Color(0xFFFF7B91)) }
            }
        }
        LazyColumn {
            items(records) { record ->
                PanelCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(record.first, fontWeight = FontWeight.Bold)
                            Text(record.second, color = Cyan)
                            Text(record.third, color = Muted, fontSize = 10.sp)
                        }
                        IconButton(onClick = {
                            records = records.filterNot { it == record }
                            storeHistory(context, records)
                        }) { Icon(Icons.Default.Delete, null, tint = Muted) }
                    }
                }
            }
        }
        if (records.isEmpty()) Text("目前沒有紀錄", color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally).padding(20.dp))
    }
}
data class HistoryItem(val first: String, val second: String, val third: String)
fun loadHistory(context: Context): List<HistoryItem> {
    val raw = context.getSharedPreferences("nexora", Context.MODE_PRIVATE).getString("history", "[]") ?: "[]"
    return try {
        val a = JSONArray(raw)
        (0 until a.length()).map { val o = a.getJSONObject(it); HistoryItem(o.getString("type"), o.getString("value"), o.getString("date")) }
    } catch (_: Exception) { emptyList() }
}
fun storeHistory(context: Context, list: List<HistoryItem>) {
    val a = JSONArray()
    list.forEach { a.put(JSONObject().put("type", it.first).put("value", it.second).put("date", it.third)) }
    context.getSharedPreferences("nexora", Context.MODE_PRIVATE).edit().putString("history", a.toString()).apply()
}
fun saveHistory(context: Context, type: String, value: String) {
    val list = loadHistory(context).toMutableList()
    val date = SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.getDefault()).format(Date())
    list.add(0, HistoryItem(type, value, date))
    storeHistory(context, list.take(100))
}
