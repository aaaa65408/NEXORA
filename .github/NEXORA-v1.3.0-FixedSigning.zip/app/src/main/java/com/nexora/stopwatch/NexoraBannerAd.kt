package com.nexora.stopwatch

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize
import com.google.android.libraries.ads.mobile.sdk.banner.AdView
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError

@Composable
fun NexoraBannerAd(sdkReady: Boolean) {
    val context = LocalContext.current
    val activity = context as? Activity ?: return
    val adView = remember(context) { AdView(context) }

    LaunchedEffect(adView, sdkReady) {
        if (sdkReady) {
            val density = context.resources.displayMetrics.density
            val widthDp = (context.resources.displayMetrics.widthPixels / density).toInt()
            val adSize = AdSize.getLargeAnchoredAdaptiveBannerAdSize(context, widthDp)
            val request = BannerAdRequest.Builder(
                NexoraAdConfig.BANNER_AD_UNIT_ID,
                adSize
            ).build()
            adView.loadAd(request, object : AdLoadCallback<BannerAd> {
                override fun onAdLoaded(ad: BannerAd) {
                    // The SDK registers the loaded banner with this AdView automatically.
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    // Keep the app usable if no test ad is returned.
                }
            })
        }
    }

    DisposableEffect(adView) {
        onDispose { adView.destroy() }
    }

    Box(
        modifier = Modifier.fillMaxWidth().wrapContentHeight().background(Color(0xFF101B35)),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier.fillMaxWidth().wrapContentHeight(),
            factory = { adView }
        )
    }
}
