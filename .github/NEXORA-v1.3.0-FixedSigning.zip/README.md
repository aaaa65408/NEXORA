# NEXORA Android

Release APKs are signed with one fixed private keystore. Never regenerate or replace that keystore. GitHub Actions needs repository secrets `NEXORA_KEYSTORE_BASE64`, `NEXORA_STORE_PASSWORD`, `NEXORA_KEY_ALIAS`, and `NEXORA_KEY_PASSWORD`. Never commit the keystore or its passwords to this repository.


## AdMob integration (v1.4.0)
- Uses Google's GMA Next-Gen Android SDK 1.7.0.
- AdMob App ID is configured programmatically during SDK initialization.
- App Open and anchored adaptive Banner placements are integrated.
- Development builds intentionally use Google's official test ad unit IDs.
- Production Ad Unit IDs supplied by the owner are stored in `NexoraAds.kt` but are not active until test mode is deliberately switched for a release.
- App Open ads are suppressed on the first app launch and are only considered on later foreground returns.
- The banner is placed below the bottom navigation and is shared by all four app tabs.


## v1.4.1 build fix
- Added missing Android Handler/Looper, coroutine, and GMA Next-Gen SDK imports.
- Added an explicit kotlinx-coroutines-android dependency.
- Passed the SDK initialization completion callback.


## v1.4.2 dependency fix
- Added androidx.fragment:fragment-ktx:1.8.5 to satisfy the AndroidX ActivityResult lint requirement (Fragment >= 1.3.0).


## v1.4.3 startup ads and banner layout
- Removed the first-launch suppression for App Open ads.
- App Open ads are attempted on cold start and on later foreground returns when an ad is available.
- The app does not enforce a five-second delay; the ad is shown as soon as it is ready.
- Moved the banner directly above the bottom navigation to avoid placing it in the system gesture/navigation area.


## v1.4.4 Play release preparation
- Updated compileSdk/targetSdk to Android 16 (API 36), versionCode 12, versionName 1.4.4.
- Added Google UMP consent update and consent-gated ad initialization.
- Added a privacy-options entry point under History.
- Debug builds use Google's official test ad units; release builds use the publisher's production Banner and App Open unit IDs.
- First installation launch does not show an App Open ad; later foreground entries may show one when an ad is preloaded.
- GitHub Actions builds and verifies both signed APK and AAB using the existing keystore secrets.
- See PRIVACY_POLICY_TEMPLATE.md: publisher must complete the contact details and publish the policy at a public HTTPS URL before Play submission.

## Release caveats
- The privacy policy template is not a substitute for a publisher-reviewed legal policy. Complete the contact fields and ensure its disclosures match actual SDK/data practices.
- Complete Play Console Data safety, Ads declaration, content rating, app access, and any foreground-service declarations.
- Run a clean GitHub Actions build and test the signed APK on physical devices before submission.
