# NEXORA Android

Release APKs are signed with one fixed private keystore. Never regenerate or replace that keystore. GitHub Actions needs repository secrets `NEXORA_KEYSTORE_BASE64`, `NEXORA_STORE_PASSWORD`, `NEXORA_KEY_ALIAS`, and `NEXORA_KEY_PASSWORD`. Never commit the keystore or its passwords to this repository.


## AdMob integration (v1.4.0)
- Uses Google's GMA Next-Gen Android SDK 1.7.0.
- AdMob App ID is configured programmatically during SDK initialization.
- App Open and anchored adaptive Banner placements are integrated.
- Development builds intentionally use Google's official test ad unit IDs.
- Production Ad Unit IDs supplied by the owner are stored in `NexoraAds.kt` but are not active until test mode is deliberately switched for a release.
- App Open ads are suppressed on the first app launch and are only considered on later foreground returns.
- The banner is placed below the bottom navigation and is shared by all four app tabs.


## v1.4.1 build fix
- Added missing Android Handler/Looper, coroutine, and GMA Next-Gen SDK imports.
- Added an explicit kotlinx-coroutines-android dependency.
- Passed the SDK initialization completion callback.


## v1.4.2 dependency fix
- Added androidx.fragment:fragment-ktx:1.8.5 to satisfy the AndroidX ActivityResult lint requirement (Fragment >= 1.3.0).
