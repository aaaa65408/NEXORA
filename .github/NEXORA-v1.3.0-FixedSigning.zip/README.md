# NEXORA Android

Release APKs are signed with one fixed private keystore. Never regenerate or replace that keystore. GitHub Actions needs repository secrets `NEXORA_KEYSTORE_BASE64`, `NEXORA_STORE_PASSWORD`, `NEXORA_KEY_ALIAS`, and `NEXORA_KEY_PASSWORD`. Never commit the keystore or its passwords to this repository.
