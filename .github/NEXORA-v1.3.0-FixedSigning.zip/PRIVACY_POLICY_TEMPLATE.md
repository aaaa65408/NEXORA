# NEXORA Privacy Policy (Publisher completion required)

**Effective date:** [YYYY-MM-DD]

**Developer / data controller:** [Your legal name or business name]

**Contact:** [A monitored privacy contact email]

NEXORA is a clock utility app providing alarms, countdown timers, stopwatch and local history.

## Information and device permissions
NEXORA stores alarm settings, countdown state and stopwatch/history entries locally on the device to provide app functions. The app requests notification permission to show reminders, vibration permission for alerts, exact-alarm capability for scheduled alarms, and foreground-service capability to continue audible alerts when the app is not in the foreground.

## Advertising and third-party services
NEXORA uses Google Mobile Ads (AdMob), including banner and app-open advertising. Google and its advertising partners may process device identifiers, IP address, app interaction and diagnostic/ad-delivery information as described in Google's policies and disclosures. Advertising consent choices are presented through Google's User Messaging Platform where required. Users can revisit available advertising privacy choices from NEXORA's History screen using “廣告隱私設定”.

Google privacy information: https://policies.google.com/privacy
Google advertising information: https://policies.google.com/technologies/ads

## Data sharing and retention
Alarm settings and history are stored locally by the app. Advertising-related data may be processed by Google as an independent service provider/controller under its applicable terms. [Publisher: describe any additional sharing, analytics, backup, crash reporting or server processing here; remove this note after completion.]

## Children's privacy
[Publisher: describe the intended audience and the measures used to comply with applicable child-protection and families policies. Do not publish until this section is accurate.]

## Security and deletion
Local app data can generally be removed by clearing app storage or uninstalling the app. Advertising data handled by Google is subject to Google's controls and policies. [Publisher: add any additional deletion/contact process.]

## Changes and contact
We may update this policy when app functionality or legal requirements change. For privacy questions, contact: [privacy email].

---
**Do not publish this template unchanged.** Replace every bracketed field, remove drafting notes, verify the statements against the actual SDK configuration and Play Console Data safety answers, and host the final policy at a stable public HTTPS URL before submitting the app.
