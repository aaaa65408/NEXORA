package com.nexora.stopwatch

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("alarm_id", 0)
        val label = intent.getStringExtra("alarm_label") ?: "NEXORA 鬧鐘"
        val channel = "nexora_alarm"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                android.app.NotificationChannel(channel, "鬧鐘提醒", android.app.NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("時間到了")
            .setContentText(label)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(context).notify(1000 + id, notification) } catch (_: SecurityException) {}
    }

    companion object {
        fun schedule(context: Context, id: Int, triggerAtMillis: Long, label: String) {
            val intent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra("alarm_id", id); putExtra("alarm_label", label)
            }
            val pi = PendingIntent.getBroadcast(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 23) {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                }
            } else am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }

        fun cancel(context: Context, id: Int) {
            val intent = Intent(context, AlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
        }
    }
}

class CountdownReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val channel = "nexora_countdown"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                android.app.NotificationChannel(channel, "倒數計時提醒", android.app.NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("NEXORA 倒數結束")
            .setContentText("設定的倒數時間已經結束")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(context).notify(2001, notification) } catch (_: SecurityException) {}
        saveHistory(context, "倒數計時", "背景完成")
        context.getSharedPreferences("nexora", Context.MODE_PRIVATE).edit()
            .putBoolean("countdown_running", false).putLong("countdown_end_epoch", 0L).apply()
    }

    companion object {
        fun schedule(context: Context, targetEpochMillis: Long) {
            val intent = Intent(context, CountdownReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                context, 2001, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 23) {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, targetEpochMillis, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, targetEpochMillis, pi)
                }
            } else am.setExact(AlarmManager.RTC_WAKEUP, targetEpochMillis, pi)
        }

        fun cancel(context: Context) {
            val pi = PendingIntent.getBroadcast(
                context, 2001, Intent(context, CountdownReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("nexora", Context.MODE_PRIVATE)
        val raw = prefs.getString("alarms", "[]") ?: "[]"
        try {
            val arr = org.json.JSONArray(raw)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                if (!item.optBoolean("enabled", false)) continue
                val id = item.getInt("id")
                val hour = item.getInt("hour")
                val minute = item.getInt("minute")
                val label = item.optString("label", "提醒")
                val cal = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, hour)
                    set(java.util.Calendar.MINUTE, minute)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
                }
                AlarmReceiver.schedule(context, id, cal.timeInMillis, label)
            }
        } catch (_: Exception) { }

        val countdownEnd = prefs.getLong("countdown_end_epoch", 0L)
        if (prefs.getBoolean("countdown_running", false) && countdownEnd > System.currentTimeMillis()) {
            CountdownReceiver.schedule(context, countdownEnd)
        } else if (prefs.getBoolean("countdown_running", false)) {
            prefs.edit().putBoolean("countdown_running", false).putLong("countdown_end_epoch", 0L).apply()
        }
    }
}
