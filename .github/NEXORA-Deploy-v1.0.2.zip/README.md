# NEXORA

NEXORA 是一款以深色科技霓虹風格設計的 Android 時間工具。

## 功能
- 秒錶：開始、暫停、繼續、重設、計次
- 倒數計時：設定時分秒、開始、暫停、繼續、重設、到期通知（背景排程）
- 鬧鐘：新增、編輯時間、啟用／停用、刪除與系統通知提醒
- 開機後恢復已啟用鬧鐘與尚未到期的倒數排程
- 歷史紀錄：保存秒錶與倒數完成紀錄、刪除單筆或清空
- 本機資料保存：使用 SharedPreferences

## 技術
- Kotlin
- Jetpack Compose / Material 3
- Android minSdk 26 / targetSdk 35
- SystemClock.elapsedRealtime() 作為秒錶與倒數計時的單調時鐘基礎

## 開啟方式
1. 使用 Android Studio 開啟此資料夾。
2. 等待 Gradle Sync。
3. 連接 Android 手機或啟動模擬器。
4. 按 Run 執行。

## 權限與提醒
Android 13 以上需要允許通知權限。Android 12 以上的精確鬧鐘可能需要在系統設定中授權「鬧鐘與提醒」；未授權時系統會退回非精確提醒。

## 目前驗證狀態
此原始碼包尚未在本工作環境完成 Gradle 編譯，也尚未於實體裝置驗證。背景通知與開機排程已加入程式碼，但仍須在 Android Studio 編譯後，於實機測試通知權限、精確鬧鐘權限、省電限制及重新開機行為。


## GitHub Actions 雲端編譯
此專案包含 `.github/workflows/android.yml`。將專案內容推送到 GitHub 的 `main` 分支後，GitHub Actions 會嘗試編譯 Debug APK，並將 `NEXORA-debug-apk` 作為 workflow artifact 保存。也可以在 GitHub 的 Actions 頁面手動執行 `Build NEXORA Android APK`。
